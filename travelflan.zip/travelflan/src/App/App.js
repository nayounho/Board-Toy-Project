import WelcomePage from "pages/WelcomePage";

function App() {
  return <WelcomePage />;
}

export default App;
